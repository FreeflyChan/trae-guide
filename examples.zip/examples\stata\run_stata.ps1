﻿# run_stata.ps1 —— 在 Trae 的终端里一键跑完全部 do 文件
# 用法：右键本文件 →「在集成终端中运行」，或在本目录终端执行：
#   powershell -ExecutionPolicy Bypass -File .\run_stata.ps1
#
# 脚本会自动在本机查找 Stata，不需要你改路径。
# 自动探测失败时，把下面这行改成你的 Stata 可执行文件路径即可：
#   $stata = "D:\Program Files\Stata18\stata18\StataMP-64.exe"
$stata = $null

$ErrorActionPreference = "Stop"

# 先把工作目录切到本脚本所在目录：do 文件里的 data/、output/ 都是相对路径
Set-Location $PSScriptRoot

# ---- 自动查找 Stata ----------------------------------------------------------
$names = @("StataMP-64.exe", "StataSE-64.exe", "StataBE-64.exe", "StataMP.exe", "StataSE.exe", "StataBE.exe")

if (-not $stata -and $env:STATA_EXE -and (Test-Path $env:STATA_EXE)) {
    $stata = $env:STATA_EXE
}

# 1) 常见安装位置（只查固定候选，不做全盘递归，避免卡住）
if (-not $stata) {
    $bases = @("D:\Program Files", "C:\Program Files", "C:\Program Files (x86)")
    foreach ($b in $bases) {
        foreach ($v in @(20, 19, 18, 17, 16)) {
            foreach ($n in $names) {
                foreach ($p in @("$b\Stata$v\stata$v\$n", "$b\Stata$v\$n", "$b\Stata\$n")) {
                    if (Test-Path $p) { $stata = $p; break }
                }
                if ($stata) { break }
            }
            if ($stata) { break }
        }
        if ($stata) { break }
    }
}

# 2) 注册表里的 App Paths（安装程序通常会写这里）
if (-not $stata) {
    $keys = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
    )
    foreach ($k in $keys) {
        $hit = Get-ChildItem $k -ErrorAction SilentlyContinue |
            Where-Object { $_.PSChildName -like "Stata*" } |
            ForEach-Object { (Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue)."(default)" } |
            Where-Object { $_ -and (Test-Path $_) } |
            Select-Object -First 1
        if ($hit) { $stata = $hit; break }
    }
}

# 3) 已加入 PATH 的情况
if (-not $stata) {
    foreach ($n in $names) {
        $cmd = Get-Command $n -ErrorAction SilentlyContinue
        if ($cmd) { $stata = $cmd.Source; break }
    }
}

# ---- 找不到就明确告诉你怎么办 ------------------------------------------------
if (-not $stata) {
    Write-Host "没有自动找到 Stata。" -ForegroundColor Red
    Write-Host "请用下面任意一种方式指定：" -ForegroundColor Yellow
    Write-Host '  1. 打开本文件，把第 9 行的 $stata = $null 改成你的 Stata 路径' -ForegroundColor Yellow
    Write-Host '  2. 在本终端执行：$env:STATA_EXE = "D:\Program Files\Stata18\stata18\StataMP-64.exe"' -ForegroundColor Yellow
    exit 1
}

Write-Host "Stata：$stata" -ForegroundColor DarkGray
Write-Host "工作目录：$PSScriptRoot" -ForegroundColor DarkGray

if (-not (Test-Path "data\panel.csv")) {
    Write-Host "缺少 data\panel.csv，请先运行：python 00_make_data.py" -ForegroundColor Red
    exit 1
}

Write-Host "开始运行 run_all.do ..." -ForegroundColor Cyan

# 用 Start-Process -Wait：Stata 的 /e 是后台模式，直接调用会立刻返回，
# 不等它写完日志就打印"结束"，容易误以为跑完了
$proc = Start-Process -FilePath $stata -ArgumentList @("/e", "do", "`"run_all.do`"") `
        -WorkingDirectory $PSScriptRoot -PassThru -Wait

if ($proc.ExitCode -ne 0) {
    Write-Host "Stata 退出码：$($proc.ExitCode)，可能有命令报错，请看 run_all.log。" -ForegroundColor Red
    exit $proc.ExitCode
}

if (Test-Path "run_all.log") {
    Write-Host "Log 最后 5 行：" -ForegroundColor DarkGray
    Get-Content "run_all.log" -Tail 5 | ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
}
Write-Host "运行结束。结果看：run_all.log 与 output\ 目录。" -ForegroundColor Green
