# -*- coding: utf-8 -*-
"""00_make_data.py —— 生成一份可复现的合成面板数据

为什么要用合成数据：
    1) 不涉及任何真实企业或个人，可以放心丢给 AI 去读、去改、去跑；
    2) 数据生成过程（DGP）是我们自己写的，真实系数已知，
       跑完回归可以对照，用来检验「AI 有没有在骗你」。

真实研究里，这一步换成从 CSMAR / CNRDS / Wind 导出的原始数据，
后面的清洗与回归流程完全一样。
"""

from pathlib import Path

import numpy as np
import pandas as pd

SEED = 20240101
N_FIRM = 300
YEARS = list(range(2010, 2021))
TRUE_EFFECT = 0.18  # 真实处理效应：政策使 ESG 提高 0.18

CITIES = [
    ("110000", "北京市"), ("310000", "上海市"), ("440100", "广州市"),
    ("440300", "深圳市"), ("330100", "杭州市"), ("320100", "南京市"),
    ("510100", "成都市"), ("420100", "武汉市"), ("610100", "西安市"),
    ("120000", "天津市"), ("370200", "青岛市"), ("350200", "厦门市"),
]


def main() -> None:
    rng = np.random.default_rng(SEED)
    root = Path(__file__).resolve().parent
    (root / "data").mkdir(parents=True, exist_ok=True)

    # 城市层面的政策时点：0 表示从未处理（对照组）
    treat_year = {}
    for code, _ in CITIES:
        treat_year[code] = 0 if rng.random() < 0.4 else int(rng.choice([2015, 2016, 2017, 2018]))

    # 企业层面的固定效应与初始特征
    firm_fe = rng.normal(0, 0.35, N_FIRM)
    firm_size_fe = rng.normal(0, 0.5, N_FIRM)
    firm_roa_fe = rng.normal(0, 0.025, N_FIRM)
    firm_city = rng.integers(0, len(CITIES), N_FIRM)
    firm_soe = rng.binomial(1, 0.35, N_FIRM)

    rows = []
    for i in range(N_FIRM):
        stkcd = f"{600000 + i:06d}"
        city_code, city_name = CITIES[firm_city[i]]
        ty = treat_year[city_code]
        for year in YEARS:
            did = 1 if (ty > 0 and year >= ty) else 0
            esg = (
                3.0
                + 0.05 * (year - 2010)
                + TRUE_EFFECT * did
                + firm_fe[i]
                + rng.normal(0, 0.12)
            )
            rows.append(
                {
                    "stkcd": stkcd,
                    "year": year,
                    "city_code": city_code,
                    "city_name": city_name,
                    "treat_year": ty,
                    "esg": round(float(esg), 3),
                    "greenwash": round(float(0.40 - 0.08 * did + firm_fe[i] * 0.2 + rng.normal(0, 0.05)), 3),
                    "size": round(float(21.0 + 0.08 * (year - 2010) + firm_size_fe[i] + rng.normal(0, 0.2)), 3),
                    "lev": round(float(np.clip(0.45 + rng.normal(0, 0.15), 0.05, 0.95)), 3),
                    "roa": round(float(0.04 + firm_roa_fe[i] + rng.normal(0, 0.03)), 4),
                    "soe": int(firm_soe[i]),
                }
            )

    df = pd.DataFrame(rows)
    out = root / "data" / "panel.csv"
    df.to_csv(out, index=False, encoding="utf-8")

    treated = df[df.treat_year > 0]["city_code"].nunique()
    print(f"已生成：{out}")
    print(f"观测值 {len(df)} 行 = {N_FIRM} 家公司 × {len(YEARS)} 年")
    print(f"处理城市 {treated} 个 / 总城市 {len(CITIES)} 个")
    print(f"真实处理效应 TRUE_EFFECT = {TRUE_EFFECT}（回归系数应接近这个值）")


if __name__ == "__main__":
    main()
