*==============================================================================
* 02_did.do —— 基准回归：双向固定效应 DID
* 模型：esg_it = a + b*did_it + gX_it + 企业FE + 年份FE + e_it
* 标准误：城市层面聚类（政策在城市层面分配，就该聚到城市）
*==============================================================================

version 17
clear all
set more off
use "data/panel_clean.dta", clear
xtset stkcd year

capture mkdir output   // 结果目录，没有就建一个

*---- (1) 只放核心解释变量 ----------------------------------------------------
xtreg esg did i.year, fe vce(cluster city_code)
estimates store m1

*---- (2) 加企业财务控制 ------------------------------------------------------
xtreg esg did size lev roa i.year, fe vce(cluster city_code)
estimates store m2

*---- (3) 再加产权性质 --------------------------------------------------------
xtreg esg did size lev roa soe i.year, fe vce(cluster city_code)
estimates store m3

*---- (4) 输出对比表 ----------------------------------------------------------
estimates table m1 m2 m3, star(.1 .05 .01) stats(N r2_a) b(%9.3f)

*---- (5) 可选：装了 estout 就顺便导出一份 Word 能打开的 RTF ---------------
capture which esttab
if _rc == 0 {
    esttab m1 m2 m3 using "output/tab_did.rtf", replace ///
        b(%9.3f) se(%9.3f) star(* 0.1 ** 0.05 *** 0.01) ///
        stats(N r2_a, labels("观测值" "调整R2")) ///
        mtitles("(1)" "(2)" "(3)") ///
        title("表1 基准回归：低碳试点对企业 ESG 的影响")
    di as result "已导出 output/tab_did.rtf"
}
else {
    di as txt "未安装 estout，跳过 RTF 导出。需要时运行：ssc install estout"
}

di as result "02_did.do 完成"
