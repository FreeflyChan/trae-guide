"""
extract.py —— 从判决书文本里抽取结构化要素

这里的案件文本用的是「标签 + 【小节】」体例：
    案号：(2022)京03民终1234号
    审理法院：北京市第三中级人民法院
    ...
    【裁判结果】...
    【援引法条】
    - 《中华人民共和国民法典》第一百四十三条

真实裁判文书不是这个体例，但抽取的思路完全一样：先定位「锚点」，
再在锚点附近用正则抓值。跑完后如果某个字段是空的，你就知道该去
改哪一条规则——这正是用 AI 编程最有效的循环：
    跑一遍 → 看哪里空 → 改规则 → 再跑。

用法（工作目录 = 本文件所在目录）：
    python extract.py

输出：
    output/elements.csv
"""

from __future__ import annotations

import csv
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
CASES = HERE / "cases"
OUTPUT = HERE / "output"

COLUMNS = [
    "case_id",
    "case_no",
    "court",
    "cause",
    "judge_date",
    "claim_amount",
    "n_articles",
    "articles",
    "result_lean",
]


def _label(text: str, name: str) -> str:
    """抓取 `标签：值` 形式的一行，返回标签后的内容。"""
    m = re.search(rf"^{name}\s*[：:]\s*(.+?)\s*$", text, flags=re.M)
    return m.group(1).strip() if m else ""


def section(text: str, name: str) -> str:
    """抓取一个【小节】的正文，直到下一个小节或文末。"""
    m = re.search(rf"【{name}】\s*(.*?)(?=\n【|\Z)", text, flags=re.S)
    return m.group(1).strip() if m else ""


def find_case_no(text: str) -> str:
    value = _label(text, "案号")
    if value:
        return value
    m = re.search(r"\((\d{4})\)\s*([^\s，。、]{1,20}?号)", text)
    return f"({m.group(1)}){m.group(2)}" if m else ""


def find_court(text: str) -> str:
    value = _label(text, "审理法院")
    if value:
        return value
    m = re.search(r"^\s*([\u4e00-\u9fa5]{2,30}?人民法院)\s*$", text, flags=re.M)
    return m.group(1).strip() if m else ""


def find_cause(text: str) -> str:
    value = _label(text, "案由")
    if value:
        return value
    m = re.search(r"([\u4e00-\u9fa5]{2,20}?纠纷)一案", text)
    return m.group(1) if m else ""


def find_date(text: str) -> str:
    value = _label(text, "裁判日期")
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return value
    return ""


def find_claim_amount(text: str) -> str:
    """诉请金额：把「3000万元」「2亿元」统一折算成元，取最大的一笔。"""
    amounts = []
    for num, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(亿|万)?元", text):
        value = float(num)
        if unit == "亿":
            value *= 100_000_000
        elif unit == "万":
            value *= 10_000
        amounts.append(int(value))
    return f"{max(amounts)}" if amounts else ""


def find_articles(text: str) -> list[str]:
    """抓【援引法条】小节里 `- 《法律名》第X条` 形式的每条援引。"""
    body = section(text, "援引法条")
    out: list[str] = []
    for law, art in re.findall(r"《([^》]+)》\s*(第[〇零一二三四五六七八九十百]+条)", body):
        item = f"《{law}》{art}"
        if item not in out:
            out.append(item)
    return out


def find_result(text: str) -> str:
    """从【裁判结果】的主文里判断结果倾向。

    按「一、二、三、」拆成判项，再逐项判断每一项对原告是支持还是驳回。
    注意：不能全文搜「支付」——因为「驳回原告要求被告支付……」这种句子
    也含「支付」，但它是驳回。所以必须先拆判项，再看判项开头。
    """
    body = section(text, "裁判结果")
    if not body:
        return "未知"

    items = [x.strip() for x in re.split(r"[一二三四五六七八九十]+、", body) if x.strip()]
    support = reject = 0
    revoke = False
    for item in items:
        if item.startswith("撤销"):
            revoke = True
            continue
        if item.startswith("驳回") or "不予支持" in item:
            reject += 1
        elif "不承担" in item:
            reject += 1
        elif "支付" in item or "承担" in item:
            support += 1

    if support and revoke:
        return "部分改判"
    if support:
        return "部分支持" if reject else "支持"
    if revoke:
        return "改判"
    if reject:
        return "驳回"
    return "未知"


def parse_case(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    articles = find_articles(text)
    return {
        "case_id": path.stem,
        "case_no": find_case_no(text),
        "court": find_court(text),
        "cause": find_cause(text),
        "judge_date": find_date(text),
        "claim_amount": find_claim_amount(text),
        "n_articles": len(articles),
        "articles": " | ".join(articles),
        "result_lean": find_result(text),
    }


def main() -> None:
    files = sorted(CASES.glob("*.txt"))
    if not files:
        print(f"没找到案件文件：{CASES}/*.txt")
        return

    rows = [parse_case(p) for p in files]

    OUTPUT.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT / "elements.csv"
    with out_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(rows)

    print(f"已解析 {len(rows)} 份判决书 → {out_path}\n")
    for r in rows:
        print(f"{r['case_id']}  {r['case_no']}  ({r['result_lean']})")
        print(f"  法院：{r['court']}   案由：{r['cause']}   裁判日期：{r['judge_date']}")
        amount = f"{int(r['claim_amount']):,}" if r["claim_amount"] else "（未载明）"
        print(f"  诉请金额：{amount} 元   援引法条 {r['n_articles']} 条")
        print(f"  法条：{r['articles']}")
        print()


if __name__ == "__main__":
    main()
