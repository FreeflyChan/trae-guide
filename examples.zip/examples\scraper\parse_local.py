"""
parse_local.py —— 用 BeautifulSoup 解析「已下载到本地」的判决书列表页

为什么先学本地解析？
  新手最容易踩的坑是：一边写解析规则，一边请求网页，出错时分不清是
  「网络问题」还是「选择器写错」。先把 HTML 存成本地文件（fixtures/），
  解析规则调通之后，再把 read_text() 换成 requests.get() 即可。

用法（在 Trae 终端里，工作目录 = 本文件所在目录）：
    python parse_local.py

输出：
    output/cases_from_html.csv

合规提醒（真实项目请遵守）：
  1. 先看目标站 robots.txt 与用户协议，确认允许抓取。
  2. 控制频率（本示例页间 sleep 0.5s），不要给对方服务器压力。
  3. 只抓公开、非敏感信息；不绕过登录、验证码、反爬。
  4. 保留原始快照，便于复核与追责。
"""

from __future__ import annotations

import csv
import time
from pathlib import Path

from bs4 import BeautifulSoup

HERE = Path(__file__).resolve().parent
FIXTURES = HERE / "fixtures"
OUTPUT = HERE / "output"
PAGES = ["page1.html", "page2.html"]

COLUMNS = ["case_no", "court", "cause", "judge_date", "title", "url"]


def parse_one(path: Path) -> list[dict]:
    """解析单个列表页，返回该页所有案件记录。"""
    html = path.read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "lxml")

    rows: list[dict] = []
    # 列表页结构：<ul class="result-list"> 下每个 <li class="item">
    for li in soup.select("ul.result-list > li.item"):
        a = li.select_one("a.title")
        if a is None:
            continue
        rows.append(
            {
                "case_no": (li.select_one("span.case-no") or a).get_text(strip=True),
                "court": _text(li, "span.court"),
                "cause": _text(li, "span.cause"),
                "judge_date": _text(li, "span.date"),
                "title": a.get_text(strip=True),
                # href 可能是相对路径，真实项目请用 urljoin 拼成绝对地址
                "url": a.get("href", ""),
            }
        )
    return rows


def _text(node, selector: str) -> str:
    el = node.select_one(selector)
    return el.get_text(strip=True) if el else ""


def dedupe(rows: list[dict]) -> list[dict]:
    """按案号去重（翻页时经常出现重复条目）。"""
    seen: set[str] = set()
    out: list[dict] = []
    for r in rows:
        key = r["case_no"]
        if key and key not in seen:
            seen.add(key)
            out.append(r)
    return out


def main() -> None:
    all_rows: list[dict] = []
    for name in PAGES:
        path = FIXTURES / name
        if not path.exists():
            print(f"[跳过] 找不到 {path}")
            continue
        rows = parse_one(path)
        print(f"{name}: 解析到 {len(rows)} 条")
        all_rows.extend(rows)
        time.sleep(0.5)  # 模拟翻页间隔；抓真站时同样需要限速

    all_rows = dedupe(all_rows)

    OUTPUT.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT / "cases_from_html.csv"
    with out_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"\n已保存：{out_path}")
    print(f"去重后共 {len(all_rows)} 条")
    for r in all_rows:
        print(f"  {r['case_no']}  {r['court']}  {r['cause']}  {r['judge_date']}")


if __name__ == "__main__":
    main()
