"""case_utils 的测试。当前应有 4 条失败，修好后全绿。

跑法（工作目录 = pyfix 根目录）：
    pytest -q
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from case_utils import bigrams, jaccard, normalize_case_no, parse_amount


def test_normalize_case_no():
    assert normalize_case_no("（2021）京 0105 民初 1234 号") == "(2021)京0105民初1234号"
    assert normalize_case_no("(2021)京0105民初1234号") == "(2021)京0105民初1234号"


def test_bigrams_count():
    # "买卖合同" 有 4 个字，二元组应为 3 个
    assert bigrams("买卖合同") == {"买卖", "卖合", "合同"}


def test_bigrams_no_single_char_gram():
    # 不应出现单字片段
    assert all(len(g) == 2 for g in bigrams("合同纠纷"))


def test_jaccard_identical():
    a = bigrams("买卖合同纠纷")
    assert jaccard(a, a) == 1.0


def test_jaccard_bounds():
    # 任意两段文本的 Jaccard 必须落在 [0, 1]
    a = bigrams("买卖合同纠纷")
    b = bigrams("买卖合同")
    score = jaccard(a, b)
    assert 0.0 <= score <= 1.0, f"Jaccard 越界：{score}"


def test_jaccard_symmetric():
    # 相似度必须对称：j(a,b) == j(b,a)
    a = bigrams("买卖合同纠纷")
    b = bigrams("买卖合同")
    assert jaccard(a, b) == jaccard(b, a), "jaccard 不对称，说明分母用错了"


def test_parse_amount_plain():
    assert parse_amount("1200.5 元") == 1200.5


def test_parse_amount_with_comma():
    assert parse_amount("1,200,000元") == 1200000.0


def test_parse_amount_with_wan():
    assert parse_amount("86万元") == 860000.0
