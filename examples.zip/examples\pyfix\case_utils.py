"""
case_utils.py —— 法律文本处理小工具（本练习含 3 处 bug）

用途：
    给你一个「能跑但有错」的小项目。请按下面的顺序练习：
    1) 先跑测试：pytest -q
    2) 读第 1 条失败信息，只改这一个问题
    3) 再跑测试，重复直到全绿

三个 bug 分别藏在：
    A. bigrams()       —— 切片范围多算了 1 个位置
    B. jaccard()       —— 分母用错了集合
    C. parse_amount()  —— 只认纯数字，忽略千分位逗号和「万」

不要一次全改完。一次只改一处、跑一次测试，才能体会「最小修复」。
"""

from __future__ import annotations

import re


def normalize_case_no(text: str) -> str:
    """案号规范化：全角括号转半角、去掉所有空白。

    (2021)京0105民初1234号
    （2021）京 0105 民初 1234 号   →   (2021)京0105民初1234号
    """
    table = str.maketrans({"（": "(", "）": ")", "　": " "})
    return re.sub(r"\s+", "", text.translate(table))


def bigrams(text: str) -> set[str]:
    """返回字符二元组集合，用于粗粒度文本相似度。

    "买卖合同" → {"买卖", "卖合", "合同"}
    """
    text = re.sub(r"\s+", "", text)
    return {text[i : i + 2] for i in range(len(text))}  # BUG A


def jaccard(a: set[str], b: set[str]) -> float:
    """Jaccard 相似度：交集 / 并集，取值应在 [0, 1]。

    完全相同 → 1.0；完全不相交 → 0.0。
    """
    if not a or not b:
        return 0.0
    return len(a & b) / len(a)  # BUG B


def parse_amount(text: str) -> float:
    """从「1,200,000元」「86万元」「1200.5 元」这类字符串里取出金额（元）。

    预期：
        "1,200,000元" → 1200000.0
        "86万元"      → 860000.0
        "1200.5 元"   → 1200.5
    """
    m = re.search(r"(\d+(?:\.\d+)?)", text)  # BUG C
    return float(m.group(1)) if m else 0.0
