*==============================================================================
* 03_robust.do —— 稳健性：换聚类层级、事件研究（平行趋势）、安慰剂检验
*==============================================================================

version 17
clear all
set more off
use "data/panel_clean.dta", clear
xtset stkcd year

*------------------------------------------------------------------------------
* (1) 更换聚类层级：企业层面 vs 城市层面
*     如果结论只在某一种聚类下显著，就要在文章里老实交代
*------------------------------------------------------------------------------
xtreg esg did size lev roa i.year, fe vce(cluster stkcd)
estimates store r_firm

xtreg esg did size lev roa i.year, fe vce(cluster city_code)
estimates store r_city

estimates table r_firm r_city, star(.1 .05 .01) stats(N) b(%9.3f)

*------------------------------------------------------------------------------
* (2) 事件研究：看政策前有没有「预趋势」
*     以政策前一年（rel = -1）为基准组
*------------------------------------------------------------------------------
gen rel = year - treat_year
gen byte ev = (treat_year > 0)

forvalues k = 5(-1)1 {
    gen byte pre`k' = (rel == -`k' & ev)
}
gen byte post0 = (rel == 0 & ev)
forvalues k = 1/4 {
    gen byte post`k' = (rel == `k' & ev)
}

xtreg esg pre5 pre4 pre3 pre2 post0 post1 post2 post3 post4 size lev roa i.year, ///
      fe vce(cluster city_code)
estimates store event

estimates table event, star(.1 .05 .01) stats(N) b(%9.3f)
di as txt "读法：pre5-pre2 若不显著，说明政策前两组趋势无系统差异；"
di as txt "      post0 起显著为正，说明政策后才出现差异。"

*------------------------------------------------------------------------------
* (3) 安慰剂：假设政策提前到 2013 年，只用 2014 年及以前的样本
*     真实政策最早 2015 年，所以这段样本里不该出现「效应」
*------------------------------------------------------------------------------
preserve
keep if year <= 2014
gen byte fake_did = (treat_year > 0 & year >= 2013)

xtreg esg fake_did size lev roa i.year, fe vce(cluster city_code)
estimates store placebo
estimates table placebo, star(.1 .05 .01) stats(N) b(%9.3f)
di as txt "fake_did 若不显著，安慰剂通过。"
restore

di as result "03_robust.do 完成"
