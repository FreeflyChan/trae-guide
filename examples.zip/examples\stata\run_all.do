*==============================================================================
* run_all.do —— 一键复现：按顺序跑完全部 do 文件
* 工作目录必须是本文件所在目录（data/、output/ 都是相对路径）。
* 用 run_stata.ps1 启动会自动设好；手动跑时先在 Stata 里 cd 到本目录。
*==============================================================================

version 17
clear all
set more off

di as txt "工作目录：`c(pwd)'"

*---- 前置检查：数据文件在不在 ----------------------------------------------
capture confirm file "data/panel.csv"
if _rc {
    di as error "找不到 data/panel.csv"
    di as error "当前工作目录：`c(pwd)'"
    di as error "两种解决方式："
    di as error "  1) 用 run_stata.ps1 启动（推荐，自动设好目录）"
    di as error "  2) 在 Stata 命令窗口先执行：cd `"<本文件所在目录>`""
    exit 601
}

do "01_clean.do"
do "02_did.do"
do "03_robust.do"

di as result "=============================================="
di as result "全部完成。日志：run_all.log；表格：output/"
di as result "=============================================="
