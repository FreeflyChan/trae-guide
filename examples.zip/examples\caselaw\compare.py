"""
compare.py —— 把多份同类判决书放在一起对比

三份案件都围绕「对赌 / 公司担保」，但处理方式不同：
  case_a  股东回购：回购条款有效，判令股东支付回购款（部分改判）
  case_b  公司回购：条款有效，但公司未完成减资程序，驳回支付请求
  case_c  公司担保：未经股东会决议 + 相对人非善意，担保对公司不发生效力

compare.py 做两件事：
  1) 生成横向对比表（要素一行一案，便于肉眼扫）
  2) 对「裁判理由」段落做文本差异（difflib），把说理的分岔点标出来

用法（工作目录 = 本文件所在目录；先跑 extract.py）：
    python compare.py

输出：
    output/comparison.md
"""

from __future__ import annotations

import csv
import difflib
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
CASES = HERE / "cases"
OUTPUT = HERE / "output"
ELEMENTS = OUTPUT / "elements.csv"

FIELDS = [
    ("case_no", "案号"),
    ("court", "法院"),
    ("cause", "案由"),
    ("judge_date", "裁判日期"),
    ("claim_amount", "诉请金额（元）"),
    ("n_articles", "援引法条数"),
    ("result_lean", "结果倾向"),
]


def read_elements() -> list[dict]:
    if not ELEMENTS.exists():
        raise SystemExit("找不到 output/elements.csv，请先运行：python extract.py")
    with ELEMENTS.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def reasoning_block(path: Path) -> list[str]:
    """取【裁判理由】小节，按句切分。"""
    text = path.read_text(encoding="utf-8")
    m = re.search(r"【裁判理由】\s*(.*?)(?=【裁判结果】|\Z)", text, flags=re.S)
    if not m:
        return []
    body = re.sub(r"\s+", "", m.group(1))
    return [s for s in re.split(r"(?<=。)", body) if s.strip()]


def build_table(rows: list[dict]) -> str:
    head = "| 要素 | " + " | ".join(r["case_id"] for r in rows) + " |"
    sep = "| --- | " + " | ".join("---" for _ in rows) + " |"
    lines = [head, sep]
    for key, label in FIELDS:
        cells = []
        for r in rows:
            value = str(r.get(key, ""))
            if key == "claim_amount" and value.isdigit():
                value = f"{int(value):,}"
            cells.append(value.replace("|", "/"))
        lines.append(f"| {label} | " + " | ".join(cells) + " |")
    return "\n".join(lines)


def build_diff(left_path: Path, right_path: Path, note: str) -> str:
    a = reasoning_block(left_path)
    b = reasoning_block(right_path)
    if not a or not b:
        return f"（{note}：没有抽到裁判理由段落，跳过）"
    diff = difflib.unified_diff(
        a, b,
        fromfile=left_path.stem,
        tofile=right_path.stem,
        lineterm="",
        n=1,
    )
    body = "\n".join(diff)
    if not body:
        return f"（{note}：两案裁判理由完全一致）"
    return f"```diff\n{body}\n```"


def main() -> None:
    rows = read_elements()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    out = OUTPUT / "comparison.md"

    parts = [
        "# 对赌与公司担保：三案对比（示例）",
        "",
        "> 本文件由 compare.py 自动生成。案件文本为教学示例，非真实裁判文书。",
        "",
        "## 一、要素横向对比",
        "",
        build_table(rows),
        "",
        "## 二、裁判理由差异（case_a → case_c）",
        "",
        "两案的分岔点不在「有没有约定」，而在**谁承担回购 / 担保义务**"
        "以及**相对人是否善意**。下面的 diff 里，`-` 是 case_a 的表述，"
        "`+` 是 case_c 的表述。",
        "",
        build_diff(CASES / "case_a.txt", CASES / "case_c.txt", "说理对比"),
        "",
        "## 三、读表提示",
        "",
        "- case_a 与 case_b 的分水岭是**义务主体**：股东回购不触及资本维持，"
        "公司回购必须先完成减资程序。",
        "- case_b 的「驳回」不是否定条款效力——判决第一项专门确认了条款有效，"
        "驳回的是「立即支付」这一履行请求。",
        "- case_c 的「改判」落在**相对人善意**上：加盖公章不等于担保有效，"
        "未审查股东会决议即难以认定为善意。",
        "- 结论差异往往不在「谁对谁错」，而在**主体身份**与**程序是否完成**。",
        "",
    ]

    out.write_text("\n".join(parts), encoding="utf-8")
    print(f"已生成：{out}")
    print(build_table(rows))


if __name__ == "__main__":
    main()
