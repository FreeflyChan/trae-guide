# -*- coding: utf-8 -*-
"""fetch_macro.py —— 从世界银行开放 API 抓取中国宏观指标

为什么拿这个当爬虫入门：
    1) 它是官方开放接口（Open Data），条款允许研究使用，不需要登录、不需要破解；
    2) 返回的是结构化 JSON，先把「取数」这件事跑通，再去处理解析 HTML 的脏活；
    3) 有分页（page / pages），正好练习翻页循环。

合规提醒（写进代码，也请写进论文的方法部分）：
    - 先看目标站点的 robots.txt 与使用条款；
    - 控制频率（本脚本每抓一个指标 sleep 0.5 秒），别把人家服务器当压测对象；
    - 抓下来的原始返回要留快照（本脚本存在 output/raw/ 下），方便复现与举证。

运行：
    python fetch_macro.py
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pandas as pd
import requests

API = "https://api.worldbank.org/v2/country/{country}/indicator/{indicator}"

INDICATORS = {
    "NY.GDP.MKTP.CD": "GDP（现价美元）",
    "NY.GDP.PCAP.CD": "人均GDP（现价美元）",
    "SP.URB.TOTL.IN.ZS": "城镇化率（%）",
    "SL.UEM.TOTL.ZS": "失业率（%）",
}

COUNTRY = "CHN"
START, END = 2005, 2023
PER_PAGE = 100
TIMEOUT = 20
RETRIES = 3


def fetch_indicator(session: requests.Session, indicator: str) -> list[dict]:
    """抓取一个指标的全部年度数据，自动翻页 + 失败重试。"""
    rows: list[dict] = []
    page = 1

    while True:
        params = {
            "format": "json",
            "per_page": PER_PAGE,
            "date": f"{START}:{END}",
            "page": page,
        }
        url = API.format(country=COUNTRY, indicator=indicator)

        for attempt in range(1, RETRIES + 1):
            try:
                resp = session.get(url, params=params, timeout=TIMEOUT)
                resp.raise_for_status()
                payload = resp.json()
                break
            except Exception as exc:  # 网络抖动、限流都可能，重试一次比直接崩好
                if attempt == RETRIES:
                    raise
                wait = 2 ** attempt
                print(f"  第 {attempt} 次失败（{exc}），{wait}s 后重试…")
                time.sleep(wait)

        meta, data = payload[0], payload[1]
        if not data:
            break

        for item in data:
            rows.append(
                {
                    "indicator": indicator,
                    "indicator_name": INDICATORS[indicator],
                    "country": item["country"]["value"],
                    "year": int(item["date"]),
                    "value": item["value"],
                }
            )

        print(f"  第 {page}/{meta['pages']} 页，累计 {len(rows)} 条")
        if page >= meta["pages"]:
            break
        page += 1
        time.sleep(0.5)  # 限速：别抓太急

    return rows


def main() -> None:
    root = Path(__file__).resolve().parent
    raw_dir = root / "output" / "raw"
    raw_dir.mkdir(parents=True, exist_ok=True)

    all_rows: list[dict] = []
    with requests.Session() as session:
        session.headers.update({"User-Agent": "trae-guide-demo/1.0 (research use)"})
        for code, name in INDICATORS.items():
            print(f"抓取：{name}（{code}）")
            all_rows.extend(fetch_indicator(session, code))
            time.sleep(0.5)

    df = pd.DataFrame(all_rows)
    df = df.dropna(subset=["value"]).sort_values(["indicator", "year"])

    out = root / "output" / "china_macro.csv"
    df.to_csv(out, index=False, encoding="utf-8-sig")  # 带 BOM，Excel 打开不乱码

    # 留一份原始快照，方便日后举证「数据是这一天抓的」
    (raw_dir / "china_macro.json").write_text(
        json.dumps(all_rows, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(f"\n已保存：{out}")
    print(f"共 {len(df)} 条观测，覆盖 {df['year'].min()}-{df['year'].max()}")
    print(df.pivot(index="year", columns="indicator_name", values="value").tail(5).round(2))


if __name__ == "__main__":
    main()
