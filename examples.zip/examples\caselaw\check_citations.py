"""
check_citations.py —— 引注核验（把判决书里的法条，与本地条文库对一遍）

它只做一件事：告诉你哪些条文能在本地库里对上，哪些对不上。
    ✓ 命中：说明条文号与法律名称在库中存在（但仍需确认版本时效）
    ? 未收录：不代表引错，只代表本地库没这条，必须回官方文本人工核对

为什么要这么保守？
    法律引注的错误有两种：一是「条文号写错」，二是「条文号对但版本已失效」。
    任何脚本都只能可靠地查第一种，第二种必须人工看时效。
    所以工具的正确用法是：缩小人工核对范围，而不是替代人工核对。

用法（工作目录 = 本文件所在目录）：
    python check_citations.py

输出：终端报告；有未收录时以退出码 1 结束（方便接进脚本/CI）
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from extract import find_articles, find_case_no

HERE = Path(__file__).resolve().parent
CASES = HERE / "cases"
REFS = HERE / "refs" / "law_articles.json"


def load_whitelist() -> dict[str, dict]:
    data = json.loads(REFS.read_text(encoding="utf-8"))
    out: dict[str, dict] = {}
    for item in data["articles"]:
        key = f"《{item['law']}》{item['article']}"
        out[key] = item
    return out


def main() -> int:
    whitelist = load_whitelist()
    total = hit = 0
    missing: list[tuple[str, str]] = []

    for path in sorted(CASES.glob("*.txt")):
        text = path.read_text(encoding="utf-8")
        case_no = find_case_no(text) or path.stem
        arts = find_articles(text)
        print(f"\n{path.stem}  {case_no}")
        if not arts:
            print("  未抽到任何援引条文（检查判决书是否有【援引法条】小节）")
            continue
        for art in arts:
            total += 1
            if art in whitelist:
                hit += 1
                print(f"  [命中] {art} —— {whitelist[art]['title']}")
            else:
                missing.append((path.stem, art))
                print(f"  [未收录] {art} —— 需回官方文本人工核对")

    print("\n" + "-" * 60)
    print(f"合计 {total} 处援引：命中 {hit} 处，未收录 {len(missing)} 处")
    if missing:
        print("\n未收录清单（不是错误，只是本库没收录）：")
        for case_id, art in missing:
            print(f"  - {case_id}: {art}")
        print(
            "\n提醒：命中也不等于没问题。请再确认"
            "（1）法律名称是否为现行有效版本；"
            "（2）条文序号是否因修法发生变动；"
            "（3）引用内容是否与条文原意一致。"
        )
        return 1

    print("全部命中示例条文库。仍需人工确认版本时效后，方可写入正式文书。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
